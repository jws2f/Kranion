#!/bin/bash
java -D64 -Xms1800m -Djava.library.path=./lib -jar Kranion.jar
