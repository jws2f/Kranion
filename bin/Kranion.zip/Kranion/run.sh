#!/bin/bash
java -D64 -cp ./lib -Djava.library.path=./lib -javaagent:./lib/jar-loader.jar -jar Kranion.jar

