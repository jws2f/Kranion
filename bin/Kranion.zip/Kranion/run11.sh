#!/bin/bash
/usr/lib/jvm/java-1.11.0-openjdk-amd64/bin/java -D64 -cp ./lib -Djava.library.path=./lib -javaagent:./lib/jar-loader.jar -jar Kranion.jar

